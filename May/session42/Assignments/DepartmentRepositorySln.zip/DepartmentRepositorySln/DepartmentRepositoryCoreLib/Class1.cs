﻿namespace DepartmentRepositoryCoreLib
{
    public class Class1
    {

    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIPVoilationApp.HighLevel
{
    internal enum ErrorLogOptions
    {
        TXT,XML
    }
}

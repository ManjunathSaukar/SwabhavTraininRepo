﻿namespace AutoFactoryCoreLib
{
    public class Class1
    {

    }
}
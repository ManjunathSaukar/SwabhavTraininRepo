﻿namespace FactoryMethodCoreLib
{
    public class Class1
    {

    }
}
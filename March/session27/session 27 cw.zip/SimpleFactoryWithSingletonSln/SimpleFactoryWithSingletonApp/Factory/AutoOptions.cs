﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleFactoryWithSingletonApp.Factory
{
    public enum AutoOptions
    {
        BMW,TESLA,AUDI
    }
}

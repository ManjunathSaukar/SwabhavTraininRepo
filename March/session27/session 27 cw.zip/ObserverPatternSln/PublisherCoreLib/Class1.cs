﻿namespace PublisherCoreLib
{
    public class Class1
    {

    }
}